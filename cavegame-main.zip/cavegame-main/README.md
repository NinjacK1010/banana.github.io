<h1 align = "center">cavegame</h1>

<h5 align = "center">
<a href = "https://github.com/yeeteeyt/cavegame/blob/main/LICENSE.txt">	
	<img alt="License" src="https://img.shields.io/badge/License-MPL--2.0-important?logo=GitHub&logoColor=white&style=for-the-badge">
</a>⠀

<a href = "https://github.com/yeeteeyt/cavegame/stargazers">	
	<img alt="Stars" src="https://img.shields.io/github/stars/yeeteeyt/cavegame?logo=GitHub&logoColor=white&style=for-the-badge">
</a>⠀

<a href = "https://github.com/yeeteeyt/cavegame/find/main">	
	<img alt="Data" src="https://img.shields.io/github/repo-size/yeeteeyt/cavegame?color=lightblue&label=Data&logo=GitHub&logoColor=white&style=for-the-badge">
</a>⠀

<a href = "https://github.com/yeeteeyt/cavegame/find/main">
	<img alt="Lines of code" src="https://img.shields.io/tokei/lines/github/yeeteeyt/cavegame?color=green&label=Lines&logo=Circle&logoColor=white&style=for-the-badge">
</a>⠀

<a href = "https://github.com/yeeteeyt/cavegame/issues">	
	<img alt="issues" src="https://img.shields.io/github/issues/yeeteeyt/cavegame?color=success&label=issues&logo=GitHub%20Actions&logoColor=white&style=for-the-badge">
</a>⠀  

</h5>

_____
<h2>Finished product</h2>
<a href = "https://yeeteeyt.github.io/cavegame/">yeeteeyt.github.io/cavegame</a>

## Our files
- [index.html](https://github.com/yeeteeyt/cavegame/blob/909d79694c6ee8412f53d1025864d63f54d15897/index.html) - The code to the GitHub page
- [codes.css](https://github.com/yeeteeyt/cavegame/blob/909d79694c6ee8412f53d1025864d63f54d15897/codes.css) - The formatting
- [codes.js](https://github.com/yeeteeyt/cavegame/blob/909d79694c6ee8412f53d1025864d63f54d15897/codes.js) - The code to the game itself
